# Yolo10 > 2024-06-19 10:35am
https://universe.roboflow.com/caro-vh/yolo10-a21kf

Provided by a Roboflow user
License: CC BY 4.0

